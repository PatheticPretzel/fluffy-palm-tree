package sample;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class Controller {
    @FXML
    private Button Go;

    @FXML
    private Button Clear;

    @FXML
    private Button Exit;

    @FXML
    private TextField X;

    @FXML
    private TextField A;

    @FXML
    private TextField B;

    @FXML
    private TextField Finish;

    @FXML
    public void Go() {
        try {
            Double x = Double.parseDouble(X.getText());
            Double a = Double.parseDouble(A.getText());
            Double b = Double.parseDouble(B.getText());

            if (x <= 7) {
                if (a == 0 && b == 0) {
                    Finish.setText("A и В не могут одновременно равняться нулю!");
                } else {
                    Finish.setText(String.valueOf((x + 4)/(a * a + b * b)));
                }
            } else {
                Finish.setText(String.valueOf(x*(a+b)*(a+b)));
            }
        } catch (Exception e) {
            Finish.setText("Введите корректные данные!");
        }
    }

    @FXML
    public void Clear() {
        X.setText("");
        A.setText("");
        B.setText("");
        Finish.setText("");
    }

    @FXML
    public void ExitAction() {
        Stage stage = (Stage) Exit.getScene().getWindow();
        stage.close();
    }
}

