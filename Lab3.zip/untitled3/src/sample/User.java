package sample;

public class User {
    private String C1;
    private String C2;
    private String C3;
    private String C4;
    private String C5;

    public User(String C1, String C2, String C3, String C4, String C5) {
        this.C1 = C1;
        this.C2 = C2;
        this.C3 = C3;
        this.C4 = C4;
        this.C5 = C5;
    }

    public User() {
    }

    public String getC1() {
        return C1;
    }

    public void setC1(String C1) {
        this.C1 = C1;
    }

    public String getC2() {
        return C2;
    }

    public void setC2(String C2) {
        this.C2 = C2;
    }

    public String getC3() {
        return C3;
    }

    public void setC3(String C3) {
        this.C3 = C3;
    }

    public String getC4() {
        return C4;
    }

    public void setC4(String C4) {
        this.C4 = C4;
    }

    public String getC5() {
        return C5;
    }

    public void setC5(String C5) {
        this.C5 = C5;
    }

}

